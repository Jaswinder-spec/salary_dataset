select * from salary_data;
-- checked for  bad data
SELECT *
FROM Salary_Data
WHERE age IS NULL OR age < 0
   OR job_title IS NULL OR job_title = ''
   OR Education_Level IS NULL OR Education_Level = ''
   OR Years_of_Experience IS NULL OR Years_of_Experience < 0
   OR salary IS NULL OR salary < 0;
   -- deleted bad data 
   DELETE FROM Salary_Data
WHERE age IS NULL OR age < 0
   OR job_title IS NULL OR job_title = ''
   OR Education_Level IS NULL OR Education_Level = ''
   OR Years_of_Experience IS NULL OR Years_of_Experience < 0
   OR salary IS NULL OR salary < 0;
--verified the cleaned data 
SELECT * FROM Salary_Data WHERE 
    age IS NULL OR age < 0 OR 
    job_title IS NULL OR job_title = '' OR 
    Education_Level IS NULL OR Education_Level = '' OR 
    Years_of_Experience IS NULL OR Years_of_Experience < 0 OR 
    salary IS NULL OR salary < 0;
	--average salary
	SELECT job_title, AVG(salary) AS avg_salary
FROM Salary_Data
GROUP BY job_title
ORDER BY avg_salary DESC;
-- select top 5
SELECT TOP 5 job_title, AVG(salary) AS avg_salary
FROM Salary_Data
GROUP BY job_title
ORDER BY avg_salary DESC;
-- salary distribution by education level
SELECT education_level, COUNT(*) AS count, AVG(salary) AS avg_salary
FROM Salary_Data
GROUP BY Education_Level
ORDER BY avg_salary DESC;
--avg salary by job title
SELECT job_title, AVG(salary) AS avg_salary
INTO JobSalarySummary
FROM Salary_Data
GROUP BY job_title;
-- salary growth rate calculation
SELECT job_title, 
       (MAX(salary) - MIN(salary)) / NULLIF(MIN(salary), 0) * 100 AS salary_growth_rate
INTO SalaryGrowthSummary
FROM Salary_data
GROUP BY job_title;
--Salary Distribution by Experience
SELECT years_of_experience , SUM(salary) AS total_salary
INTO ExperienceSalarySummary
FROM Salary_Data
GROUP BY years_of_experience;
-- Average Salary by Job Title
SELECT job_title, AVG(salary) AS avg_salary
INTO JobSalarySummary
FROM SalaryData
GROUP BY job_title;

--Salary Growth Rate by Job Title
SELECT  Education_Level, AVG(salary) AS avg_salary, COUNT(*) AS employee_count
INTO EducationSalarySummary
FROM Salary_Data
GROUP BY education_level;

--salary distribution by experience
SELECT years_of_experience, SUM(salary) AS total_salary
INTO ExperienceSalarySummary
FROM Salary_Data
GROUP BY Years_of_Experience;

--salary distribution by education level
SELECT education_level, AVG(salary) AS avg_salary, COUNT(*) AS employee_count
INTO EducationSalarySummary
FROM Salary_Data
GROUP BY education_level;

--verify the tables
SELECT * FROM JobSalarySummary;
SELECT * FROM SalaryGrowthSummary;
SELECT * FROM ExperienceSalarySummary;
SELECT * FROM EducationSalarySummary;






